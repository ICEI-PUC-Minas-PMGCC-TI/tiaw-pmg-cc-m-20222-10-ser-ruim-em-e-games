
function leDados() {
    let strDados = localStorage.getItem('db');
    let objDados = {};
    if (strDados) {
        objDados = JSON.parse(strDados);
    } else {
        objDados = {
            "dicas": [
                {
                    "lapide": false,
                    "id": 0,
                    "habilidade": "Farmar",
                    "descricao": "Farmar é uma habilidade que permite que você ganhe mais dinheiro e itens no jogo.",
                    "categoria": "Wave",
                    "midia": "https://www.youtube.com/watch?v=sR5iKfqvvk8",
                    "dificuldade": "Iniciante",
                },
                {
                    "lapide": false,
                    "id": 1,
                    "habilidade": "Controle de Mana",
                    "descricao": "Controle de Mana é uma habilidade que permite que você use mais habilidades no jogo.",
                    "categoria": "Skills do personagem",
                    "midia": "https://www.youtube.com/watch?v=KUzvBEqhpUE",
                    "dificuldade": "Intermediário",
                },
                {
                    "lapide": false,
                    "id": 2,
                    "habilidade": "Rotações",
                    "descricao": "Rotação é a capacidade de andar pelo mapa e procurar jogadas, feita de maneira correta uma boa rotação impede que o inimigo ganhe vantagem.",
                    "categoria": "Controle de Mapa",
                    "midia": "https://www.youtube.com/watch?time_continue=1&v=ykC6Z_5-9sA&feature=emb_logo",
                    "dificuldade": "Avançado",
                },
                {
                    "lapide": false,
                    "id": 3,
                    "habilidade": "Jogar de Suporte",
                    "descricao": "Jogar de Suporte é uma habilidade que permite que você ajude seus companheiros de equipe a ganhar o jogo.",
                    "categoria": "Suporte",
                    "midia": "https://www.youtube.com/watch?v=ke_ju5ZhbD8",
                    "dificuldade": "Iniciante",
                }
            ],
            "usuario": [
                {
                    "lapide": false,
                    "id": 0,
                    "jogo": "LOL",
                    "nome": "Felipe Gonçalves",
                    "nick": "brTT",
                    "funcao": "Coach",
                    "elo": "Desafiante",
                    "discord": "brTT#0001",
                    "avatar": "",
                    "descricao": "Ex-jogador profissional buscando ajudar novos jogadores a melhorarem",
                },
                {
                    "lapide": false,
                    "id": 1,
                    "jogo": "LOL",
                    "nome": "Besourinho",
                    "nick": "Besourinho",
                    "funcao": "Aluno",
                    "elo": "Prata",
                    "discord": "besourinho#9323",
                    "avatar": "",
                    "descricao": "Jogador casual e ruim que quer aprender a farmar",
                },
                {
                    "lapide": false,
                    "id": 2,
                    "jogo": "Valorant",
                    "nome": "Daniel da Silveira",
                    "nick": "Pancho",
                    "funcao": "Aluno",
                    "elo": "Ferro",
                    "discord": "Daniel S M#2471",
                    "avatar": "",
                    "descricao": "Acabei de instalar Valorant e gostaria de aprender a jogar, nunca joguei FPS antes",
                },
                {
                    "lapide": false,
                    "id": 3,
                    "jogo": "Valorant",
                    "nome": "Gabriel Toledo",
                    "nick": "FalleN",
                    "funcao": "Coach",
                    "elo": "Radiante",
                    "discord": "FalleN#0002",
                    "avatar": "",
                    "descricao": "Jogador profissional de CS:GO, bicampeão mundial disposto a ensinar o básico de FPS para novatos no Valorant ",
                }
            ]
        }
            ;
    }
    return objDados;
}

function salvaDados(dados) {
    localStorage.setItem('db', JSON.stringify(dados));
}
function addCadastro() {
    let dados = leDados();
    let jogo = "";
    let funcao = "";
    if (document.getElementById("campoJogo").value == 1) {
        jogo = "LOL";
    } else if (document.getElementById("campoJogo").value == 2) {
        jogo = "Valorant";
    }
    if (document.getElementById("campoFuncao").value == 1) {
        funcao = "Aluno";
    } else if (document.getElementById("campoFuncao").value == 2) {
        funcao = "Coach";
    }
    let membro = {
        "lapide": false,
        "id": dados.usuario.length,
        "jogo": jogo,
        "nome": document.getElementById("campoNome").value,
        "nick": document.getElementById("campoNick").value,
        "funcao": funcao,
        "elo": document.getElementById("campoElo").value,
        "discord": document.getElementById("campoDiscord").value,
        "avatar": document.getElementById("campoAvatar").value, 
        "descricao": document.getElementById("campoDescricao").value,
    }   
    dados.usuario.push(membro);
    salvaDados(dados);
    alert("Membro adicionado com sucesso!");
    window.location.href = "cadastro.html";
    mostraMembros();
}

function mostraMembros() {

    let tela = document.getElementById("tela");
    let strHtml = "";
    let objDados = leDados();
    for (i = 0; i < objDados.usuario.length; i++) {
        CurrentUser = objDados.usuario[i];
        if (!CurrentUser.lapide){
        strHtml += `<div id=${i} class=membro>`;
        strHtml += `<p><b>ID: </b>${CurrentUser.id}  `;
        strHtml += ` <b>Jogo: </b>${CurrentUser.jogo}  `;
        strHtml += ` <b>Nome: </b>${CurrentUser.nome}  `;
        strHtml += ` <b>Nick: </b>${CurrentUser.nick}  `;
        strHtml += ` <b>Função: </b>${CurrentUser.funcao}  `;
        strHtml += ` <b>Elo: </b>${CurrentUser.elo}  `;
        strHtml += ` <b>Discord: </b>${CurrentUser.discord}</p>`;
        strHtml += `<p><b>Descrição: </b>${CurrentUser.descricao}</p>`;
        strHtml += "</div>";
    }
    }
    tela.innerHTML = strHtml;
}
//buttons
document.getElementById("botaoSalvar").addEventListener("click", addCadastro)
document.getElementById("botaoAlterar").addEventListener("click", editaDica)
document.getElementById("botaoApagar").addEventListener("click", apagaMembro)

function editaDica() {
    let dados = leDados();
    let jogo = "";
    let funcao = "";
    if (document.getElementById("campoJogo").value == 1) {
        jogo = "LOL";
    } else if (document.getElementById("campoJogo").value == 2) {
        jogo = "Valorant";
    }
    if (document.getElementById("campoFuncao").value == 1) {
        funcao = "Aluno";
    } else if (document.getElementById("campoFuncao").value == 2) {
        funcao = "Coach";
    }
    let membro = {
        "lapide": false,
        "id": dados.usuario[index].id,
        "jogo": jogo,
        "nome": document.getElementById("campoNome").value,
        "nick": document.getElementById("campoNick").value,
        "funcao": funcao,
        "elo": document.getElementById("campoElo").value,
        "discord": document.getElementById("campoDiscord").value,
        "avatar": document.getElementById("campoAvatar").value, 
        "descricao": document.getElementById("campoDescricao").value,
    }   
    dados.usuario[index]=membro;
    salvaDados(dados);
    alert("Membro alterado com sucesso!");
    console.log("editaMembro");
    window.location.href = "cadastro.html";
    mostraMembros();
}

function apagaMembro(){
    let dados = leDados();
    dados.usuario[index].lapide = true;
    salvaDados(dados);
    alert("Membro apagado com sucesso!");
    window.location.href = "cadastro.html";
    mostraMembros();
    console.log("apagaMembro");
}

function CheckClickMembro() {
    let lista = document.querySelectorAll(".membro");
    lista.forEach((item) => {
        item.onclick = trataEvento;
    });
}
let trataEvento = (evento) => {
    let objDados = leDados();
    let jogo = "";
    let funcao = "";
    currentUser = objDados.usuario[$(evento.currentTarget).attr("id")];
    index = currentUser.id;
    console.log(currentUser);
    document.getElementById("campoNome").value = currentUser.nome;
    document.getElementById("campoNick").value = currentUser.nick;
    document.getElementById("campoElo").value = currentUser.elo;
    document.getElementById("campoDescricao").value = currentUser.descricao;
    document.getElementById("campoDiscord").value = currentUser.discord;
    document.getElementById("campoAvatar").value = currentUser.avatar;
    if (currentUser.jogo == "LOL") {
        jogo = 1;
    } else if (currentUser.jogo == "Valorant") {
        jogo = 2;
    }
    if (currentUser.funcao == "Aluno") {
        funcao = 1;
    } else if (currentUser.funcao == "Coach") {
        funcao = 2;
    }
    document.getElementById("campoJogo").value = jogo;
    document.getElementById("campoFuncao").value = funcao;
    checkChange();
  };


function checkChange(){
    if(index >= 0) {
        botaoAlterar.disabled = false;
        botaoApagar.disabled = false;
    }
}


    onload = () => {
        var index = -1;
        console.log("Página carregada");
        mostraMembros();
        botaoSalvar.disabled = true;
        botaoAlterar.disabled = true;
        botaoApagar.disabled = true;
        let ValidaForm = () => {
            if (campoJogo.value == 0 || campoNome.value == "" || campoNick.value == "" || campoFuncao.value == 0 || campoElo.value == "" || campoDiscord.value == "" || campoDescricao.value == "" ){
                botaoSalvar.disabled = true;
            } else {
                botaoSalvar.disabled = false;
            }
        }
        campoJogo.onchange = ValidaForm;
        campoNome.onchange = ValidaForm;
        campoNick.onchange = ValidaForm;
        campoFuncao.onchange = ValidaForm;
        campoElo.onchange = ValidaForm;
        campoDiscord.onchange = ValidaForm;
        campoDescricao.onchange = ValidaForm;
        CheckClickMembro();
    }



