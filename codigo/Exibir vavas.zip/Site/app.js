function leDados () {
    let strDados = localStorage.getItem('db');
    let objDados = {};

    if (strDados) {
        objDados = JSON.parse (strDados);
    }
    else {
        objDados = { contatos: [ 
                        {nome: "Lineup viper roubado", descricao: "Lineup viper que eu descobri no breeze", link: "https://www.youtube.com/embed/TUZb4pQr6qY", agente: "Viper", tipo: "lineup", mapa: "breeze"},
                        {nome: "Setup killjoy ascent", descricao: "Setup de radiante de killjoy confia", link: "https://www.youtube.com/embed/GKG5Ijg1_CI", agente: "KillJoy", tipo: "setup", mapa: "Ascent"},
                        {nome: "Dica posicionamento de mira", descricao: "Melhorando posicionamento de mira", link: "https://www.youtube.com/embed/5AjsNDxrOTQ", agente: "Todos", tipo: "Mira", mapa: "Todos"},
                        {nome: "Oneway omen roubada haven", descricao: "Kill ez de omen haven", link: "https://www.youtube.com/embed/oCedfgc33SY", agente: "Omen", tipo: "Lineup", mapa: "haven"}
                    ]}
    }

    return objDados;
}

function salvaDados (dados) {
    localStorage.setItem ('db', JSON.stringify (dados));
}

function incluirContato (){
    // Ler os dados do localStorage
    let objDados = leDados();

    // Incluir um novo contato
    let strNome = document.getElementById ('campoNome').value;
    let strDescricao = document.getElementById ('campoDescricao').value;
    let strLink = document.getElementById ('campoLink').value;
    let strAgente = document.getElementById ('campoAgente').value;
    let strTipo = document.getElementById ('campoTipo').value;
    let strMapa = document.getElementById ('campoMapa').value;
    let novoContato = {
        nome: strNome,
        descricao: strDescricao,
        link: strLink,
        agente: strAgente,
        tipo: strTipo,
        mapa: strMapa
    };
    objDados.contatos.push (novoContato);

    // Salvar os dados no localStorage novamente
    salvaDados (objDados);

    // Atualiza os dados da tela
    imprimeDados ();
}

function imprimeDados () {
    let tela = document.getElementById('tela');
    let strHtml = '';
    let objDados = leDados ();

    for (i=0; i< objDados.contatos.length; i++) {
        strHtml += `<p><h10>${objDados.contatos[i].nome}<\h10></p>- <p><h10>${objDados.contatos[i].descricao}</h10></p>- </p><iframe width="100%" height="30%" src=${objDados.contatos[i].link} title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen=""></iframe></p> - </p><h10> TAGS: ${objDados.contatos[i].agente}</h10></p> - </p><h10>${objDados.contatos[i].tipo}</h10></p> - <p><h10>${objDados.contatos[i].mapa}</h10></p> - <p> </p> - <p> </p> - <p> </p>==============================================================================================================================`
}

    tela.innerHTML = strHtml;
}

// Configura os botões
document.getElementById ('btnCarregaDados').addEventListener ('click', imprimeDados);
document.getElementById ('btnIncluirContato').addEventListener ('click', incluirContato);

